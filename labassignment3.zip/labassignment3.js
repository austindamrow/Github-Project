function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(51);
  let mx=25;
  let my=50;
  let px=100;
  let py=150;
  let fr=200;
  strokWeight (10);
  stroke(0, 102);
	frameRate(fr);
  
}
function draw()
{let fr=sqrt(50)
frameRate(fr);
print(fr);
let mx=mouseX;
let my=mouseY;
let px =pmouseX;
let py=pmouseY;
var weight= dist(mx, my. px, py);
colorMode(RGB, 255, 1, 51, 155);
strokeWeight (weight);
stroke(100, 25, 50, 0.25);
line(25, 50, 100, 200)
}